#include <login.h>

int main()
{
	link_info peerinfo;

	int server_sockfd;
	int addrlen=sizeof(struct sockaddr_in);
	pid_t pid;
	MSG msg;
	struct sockaddr_in server_addr,peer_addr;
	link_info *l=link_info_create();
	link_info *temp=l;
	server_sockfd=server_init(&server_addr);
/*	if((pid=fork())<0)
	{
		perror("Fail to fork");
		exit(-1);
	}
	if(pid==0)
	{
		while(1)
		{
			int re;
			//转发
			if((re=recvfrom(server_sockfd,&msg,sizeof(msg),0,(struct sockaddr *)&peer_addr,&addrlen))<0)
			{
				perror("Fail to recv");
				exit(-1);
			}
			while(temp->next!=NULL)
			{
				if(strcmp(temp->next->username,msg.peer_name)==0);
					break;
				temp=temp->next;
			}
			if(temp->next==NULL)
				printf("%s is not online",msg.peer_name);
			sendto(server_sockfd,&msg,sizeof(msg),0,(struct sockaddr *)&temp->next->addr,sizeof(struct sockaddr));
		}
	}*/
//	if(pid>0)
//	{
		while(1)
		{
			server_login_register(l,&peerinfo,server_sockfd);
		}
//	}
	exit(0);
}
