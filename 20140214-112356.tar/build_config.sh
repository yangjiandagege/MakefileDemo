sed -i 's/ENABLE_DEBUG =.*/ENABLE_DEBUG = 1/g' ./config.mk 
